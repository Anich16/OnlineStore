import React, {Component} from 'react';
import logo from './logo.svg';
import styles from './App.module.css';
import ProductPage from "./ui/ProductPage/ProductPage";
import HomePage from "./ui/HomePage/HomePage";
import CatalogPage from "./ui/CatalogPage/CatalogPage";


class App extends Component {
    render() {
        return (
            <div className={styles.App}>
                <div>
                    <div><a>Home</a></div>
                    <div><a>Catalog</a></div>
                </div>
               {/*<ProductPage />*/}
                {/*<HomePage />*/}
                <CatalogPage />
            </div>
        );
    }
}

export default App;
