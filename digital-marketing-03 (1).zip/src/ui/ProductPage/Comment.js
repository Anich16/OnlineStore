import React from 'react';

const Comment = () => {
    return <div>Я купил этот телефон, а он не работает</div>
}

export default Comment;